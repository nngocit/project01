/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","bg",{clear:"Изчистване",highlight:"Осветяване",options:"Цветови опции",selected:"Изберете цвят",title:"Изберете цвят"});