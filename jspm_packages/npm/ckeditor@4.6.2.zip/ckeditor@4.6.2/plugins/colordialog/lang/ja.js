/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","ja",{clear:"クリア",highlight:"ハイライト",options:"カラーオプション",selected:"選択された色",title:"色選択"});