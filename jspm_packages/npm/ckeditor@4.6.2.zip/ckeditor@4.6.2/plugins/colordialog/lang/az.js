/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","az",{clear:"Təmizlə",highlight:"Ayırmaq",options:"Rəng seçimləri",selected:"Seçilmiş rəng",title:"Rəngi seç"});