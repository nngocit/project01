/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","id",{clear:"Hapus",highlight:"Sorot",options:"Pilihan Warna",selected:"Warna Dipilih",title:"Pilih Warna"});