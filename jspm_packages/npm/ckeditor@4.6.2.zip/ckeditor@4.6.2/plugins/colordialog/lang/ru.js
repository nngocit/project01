/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","ru",{clear:"Очистить",highlight:"Под курсором",options:"Настройки цвета",selected:"Выбранный цвет",title:"Выберите цвет"});