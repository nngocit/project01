/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","pt-br",{clear:"Limpar",highlight:"Grifar",options:"Opções de Cor",selected:"Cor Selecionada",title:"Selecione uma Cor"});