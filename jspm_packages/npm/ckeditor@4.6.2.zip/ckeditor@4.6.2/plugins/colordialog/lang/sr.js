/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","sr",{clear:"Clear",highlight:"Highlight",options:"Color Options",selected:"Selected Color",title:"Select color"});