/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","he",{clear:"ניקוי",highlight:"סימון",options:"אפשרויות צבע",selected:"בחירה",title:"בחירת צבע"});