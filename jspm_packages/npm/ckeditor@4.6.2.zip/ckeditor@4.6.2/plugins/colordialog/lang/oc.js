/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","oc",{clear:"Escafar",highlight:"Puntada",options:"Opcions de color",selected:"Color seleccionada",title:"Seleccionar una color"});