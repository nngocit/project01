/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","lv",{clear:"Notīrīt",highlight:"Paraugs",options:"Krāsas uzstādījumi",selected:"Izvēlētā krāsa",title:"Izvēlies krāsu"});