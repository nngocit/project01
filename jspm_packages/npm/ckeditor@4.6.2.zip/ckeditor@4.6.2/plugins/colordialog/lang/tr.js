/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","tr",{clear:"Temizle",highlight:"İşaretle",options:"Renk Seçenekleri",selected:"Seçilmiş",title:"Renk seç"});