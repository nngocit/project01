/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","gl",{clear:"Limpar",highlight:"Resaltar",options:"Opcións de cor",selected:"Cor seleccionado",title:"Seleccione unha cor"});