/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","da",{clear:"Nulstil",highlight:"Markér",options:"Farvemuligheder",selected:"Valgt farve",title:"Vælg farve"});