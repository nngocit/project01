/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","it",{clear:"cancella",highlight:"Evidenzia",options:"Opzioni colore",selected:"Seleziona il colore",title:"Selezionare il colore"});