/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","gu",{clear:"સાફ કરવું",highlight:"હાઈઈટ",options:"રંગના વિકલ્પ",selected:"પસંદ કરેલો રંગ",title:"રંગ પસંદ કરો"});