/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","fr",{clear:"Effacer",highlight:"Pointée",options:"Options de couleur",selected:"Couleur choisie",title:"Sélectionner une couleur"});