/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("colordialog","en-gb",{clear:"Clear",highlight:"Highlight",options:"Colour Options",selected:"Selected Colour",title:"Select colour"});