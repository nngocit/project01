/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","tr",{embeddingInProgress:"Yapıştırdığınız URL gömülmeye çalışılıyor...",embeddingFailed:"Bu URL otomatik olarak gömülemedi."});