/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","sv",{embeddingInProgress:"Försöker bädda in inklistrad URL...",embeddingFailed:"Denna URL kunde inte automatiskt bäddas in."});