/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","oc",{embeddingInProgress:"Incorporacion de l'URL pegada...",embeddingFailed:"Aquesta URL a pas pogut èsser incorporada automaticament."});