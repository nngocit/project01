/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","es",{embeddingInProgress:"Intentando incrustar URL pegada...",embeddingFailed:"Está URL no pudo ser automáticamente incrustada."});