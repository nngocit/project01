/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","ku",{embeddingInProgress:"لەهەوڵی لکاندنی بەستەری ناونیشانە...",embeddingFailed:"ئەم بەستەرە خۆکارانە ناتواندرێت بخرێتە ناوێ."});