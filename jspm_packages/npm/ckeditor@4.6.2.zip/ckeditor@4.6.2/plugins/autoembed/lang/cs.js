/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","cs",{embeddingInProgress:"Pokus o vnoření vložené URL",embeddingFailed:"Tato URL nemůže být automaticky vnořena."});