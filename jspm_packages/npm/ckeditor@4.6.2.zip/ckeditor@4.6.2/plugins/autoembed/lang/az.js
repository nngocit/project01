/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","az",{embeddingInProgress:"Dahil etdiyiniz link yerləşdirilir...",embeddingFailed:"Bu cür linki avtomatik yerləşdirmək mövcud deyil."});