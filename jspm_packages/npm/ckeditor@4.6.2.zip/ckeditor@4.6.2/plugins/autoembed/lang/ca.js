/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","ca",{embeddingInProgress:"Provant d'incrustar URL copiada...",embeddingFailed:"Aquesta URL no es pot incrustar automàticament."});