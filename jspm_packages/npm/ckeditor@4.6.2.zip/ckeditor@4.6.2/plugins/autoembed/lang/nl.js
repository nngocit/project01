/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","nl",{embeddingInProgress:"De geplakte URL wordt ingesloten...",embeddingFailed:"Deze URL kon niet automatisch ingesloten worden."});