/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("autoembed","sk",{embeddingInProgress:"Snažím sa vložiť skopírovanú URL...",embeddingFailed:"Túto URL nebolo možné automaticky vložiť."});