/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","ru",{ltr:"Направление текста слева направо",rtl:"Направление текста справа налево"});