/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","tr",{ltr:"Metin yönü soldan sağa",rtl:"Metin yönü sağdan sola"});