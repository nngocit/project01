/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","th",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});