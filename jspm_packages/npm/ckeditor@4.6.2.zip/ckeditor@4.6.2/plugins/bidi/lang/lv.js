/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","lv",{ltr:"Teksta virziens no kreisās uz labo",rtl:"Teksta virziens no labās uz kreiso"});