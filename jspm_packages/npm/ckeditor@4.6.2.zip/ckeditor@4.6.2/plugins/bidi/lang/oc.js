/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","oc",{ltr:"Direccion del tèxte d'esquèrra cap a dreita",rtl:"Direccion del tèxte de dreita cap a esquèrra"});