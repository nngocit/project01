/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","nl",{ltr:"Schrijfrichting van links naar rechts",rtl:"Schrijfrichting van rechts naar links"});