/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","zh",{ltr:"文字方向從左至右",rtl:"文字方向從右至左"});