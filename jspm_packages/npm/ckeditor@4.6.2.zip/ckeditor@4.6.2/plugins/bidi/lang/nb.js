/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","nb",{ltr:"Tekstretning fra venstre til høyre",rtl:"Tekstretning fra høyre til venstre"});