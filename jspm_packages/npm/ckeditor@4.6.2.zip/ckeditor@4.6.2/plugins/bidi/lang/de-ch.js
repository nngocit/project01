/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","de-ch",{ltr:"Leserichtung von Links nach Rechts",rtl:"Leserichtung von Rechts nach Links"});