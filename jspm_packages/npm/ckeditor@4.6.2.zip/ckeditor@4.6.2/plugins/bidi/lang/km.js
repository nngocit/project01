/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","km",{ltr:"ទិស​ដៅ​អក្សរ​ពី​ឆ្វេង​ទៅ​ស្ដាំ",rtl:"ទិស​ដៅ​អក្សរ​ពី​ស្ដាំ​ទៅ​ឆ្វេង"});