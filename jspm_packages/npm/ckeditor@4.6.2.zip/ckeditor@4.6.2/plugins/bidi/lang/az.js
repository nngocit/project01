/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","az",{ltr:"Mətnin istiqaməti - soldan sağa",rtl:"Mətnin istiqaməti - sağdan sola"});