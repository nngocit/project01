/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","sr",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});