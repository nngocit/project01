/* */ 
"format cjs";
﻿CKEDITOR.plugins.setLang("bidi","en-ca",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});